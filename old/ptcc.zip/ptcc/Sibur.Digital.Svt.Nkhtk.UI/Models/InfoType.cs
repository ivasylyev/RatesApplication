namespace Sibur.Digital.Svt.Nkhtk.UI.Models;

public enum InfoType
{
    Info,
    Error
}