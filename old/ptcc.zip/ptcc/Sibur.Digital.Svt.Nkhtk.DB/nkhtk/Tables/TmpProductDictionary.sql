﻿CREATE TABLE [nkhtk].[TmpProductDictionary] (
    [MaterialCode]     NVARCHAR (255) NOT NULL,
    [ProductGroupCode] NVARCHAR (255) NOT NULL,
    [ETSNGCode]        NVARCHAR (255) NOT NULL
);

