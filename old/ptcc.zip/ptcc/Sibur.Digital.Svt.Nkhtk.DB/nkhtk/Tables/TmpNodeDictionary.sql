﻿CREATE TABLE [nkhtk].[TmpNodeDictionary] (
    [NKHTK_Name] NVARCHAR (255) NOT NULL,
    [SVT_Name]   NVARCHAR (255) NOT NULL,
    [SVT_Code]   NVARCHAR (255) NOT NULL
);

