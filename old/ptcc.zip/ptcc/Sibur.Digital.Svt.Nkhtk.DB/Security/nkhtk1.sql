﻿CREATE SCHEMA [nkhtk1]
    AUTHORIZATION [dbo];

