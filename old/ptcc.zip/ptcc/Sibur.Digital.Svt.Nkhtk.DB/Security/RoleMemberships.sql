﻿


GO



GO



GO



GO



GO



GO



GO



GO
ALTER ROLE [db_datawriter] ADD MEMBER [svt_integ_user];




GO
ALTER ROLE [db_datareader] ADD MEMBER [SIBUR\G001GG-SVTDBsrv-Admin];




GO
ALTER ROLE [db_owner] ADD MEMBER [DEV002\vasilevivv];


GO
ALTER ROLE [db_owner] ADD MEMBER [goncharovkmdev];


GO
ALTER ROLE [db_owner] ADD MEMBER [DEV002\OleynerAO];


GO
ALTER ROLE [db_owner] ADD MEMBER [DEV002\SudakovAA];


GO
ALTER ROLE [db_owner] ADD MEMBER [SIBUR\A001-TSTSVTWEBsvc];


GO
ALTER ROLE [db_owner] ADD MEMBER [SIBUR\G001GG-TST-SVTDBsrv-Admin];


GO
ALTER ROLE [db_owner] ADD MEMBER [SIBUR\A001SVT-WEBsvc];


GO
ALTER ROLE [db_owner] ADD MEMBER [SIBUR\A001SVT-SQLsvc];

