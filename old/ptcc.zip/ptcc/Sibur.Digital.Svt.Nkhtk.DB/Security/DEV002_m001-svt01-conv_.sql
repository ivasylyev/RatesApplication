﻿CREATE USER [DEV002\m001-svt01-conv$] FOR LOGIN [DEV002\m001-svt01-conv$];











