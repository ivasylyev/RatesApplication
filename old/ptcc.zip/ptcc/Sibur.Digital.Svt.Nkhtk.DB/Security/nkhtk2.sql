﻿CREATE SCHEMA [nkhtk2]
    AUTHORIZATION [dbo];

