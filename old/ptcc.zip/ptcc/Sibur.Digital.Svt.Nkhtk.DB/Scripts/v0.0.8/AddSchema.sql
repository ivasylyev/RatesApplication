﻿
CREATE SCHEMA [nkhtk]
    AUTHORIZATION [dbo];



GO